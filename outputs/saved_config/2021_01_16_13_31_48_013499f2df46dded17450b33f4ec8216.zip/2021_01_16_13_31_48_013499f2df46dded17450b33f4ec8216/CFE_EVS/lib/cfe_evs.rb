# This class can be used in your scripts like so:
#   require 'cfe_evs'
#   cfe_evs = Cfe_evs.new
#   cfe_evs.utility
# For more information see the COSMOS scripting guide

class Cfe_evs
  def utility
  end
end
