# This class can be used in your scripts like so:
#   require 'cfs_pi'
#   cfs_pi = Cfs_pi.new
#   cfs_pi.utility
# For more information see the COSMOS scripting guide

class Cfs_pi
  def utility
  end
end
