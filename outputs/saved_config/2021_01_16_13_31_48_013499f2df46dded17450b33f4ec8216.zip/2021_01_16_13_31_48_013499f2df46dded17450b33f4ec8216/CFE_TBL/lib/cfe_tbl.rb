# This class can be used in your scripts like so:
#   require 'cfe_tbl'
#   cfe_tbl = Cfe_tbl.new
#   cfe_tbl.utility
# For more information see the COSMOS scripting guide

class Cfe_tbl
  def utility
  end
end
