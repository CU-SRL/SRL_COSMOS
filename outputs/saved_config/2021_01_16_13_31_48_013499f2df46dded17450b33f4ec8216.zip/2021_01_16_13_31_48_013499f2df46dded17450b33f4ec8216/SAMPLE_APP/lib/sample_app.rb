# This class can be used in your scripts like so:
#   require 'sample_app'
#   sample_app = Sample_app.new
#   sample_app.utility
# For more information see the COSMOS scripting guide

class Sample_app
  def utility
  end
end
