# This class can be used in your scripts like so:
#   require 'cfe_sb'
#   cfe_sb = Cfe_sb.new
#   cfe_sb.utility
# For more information see the COSMOS scripting guide

class Cfe_sb
  def utility
  end
end
