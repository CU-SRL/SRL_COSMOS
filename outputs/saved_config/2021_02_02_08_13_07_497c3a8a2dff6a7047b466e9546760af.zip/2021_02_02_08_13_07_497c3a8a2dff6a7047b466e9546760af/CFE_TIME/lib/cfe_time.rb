# This class can be used in your scripts like so:
#   require 'cfe_time'
#   cfe_time = Cfe_time.new
#   cfe_time.utility
# For more information see the COSMOS scripting guide

class Cfe_time
  def utility
  end
end
