# This class can be used in your scripts like so:
#   require 'to_lab'
#   to_lab = To_lab.new
#   to_lab.utility
# For more information see the COSMOS scripting guide

class To_lab
  def utility
  end
end
